Cracking ZIP files with JtR Jumbo
=================================

1. Run zip2john on password protected .zip file(s).

E.g. $ ../run/zip2john target.zip > hash

2. Run john on the output of zip2john.

E.g. $ ../run/john hash

3. Wait for the password to get cracked.
