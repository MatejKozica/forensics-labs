Cracking Password Safe 3.x and Password Gorilla databases with john
===================================================================

1. Run pwsafe2john on .psafe3 files.

E.g. $ ../run/pwsafe2john pwsafe-openwall.psafe3 > hashes

2. Run john on the output of pwsafe2john.

E.g. $ ../run/john hashes

3. Wait for the password to get cracked.
