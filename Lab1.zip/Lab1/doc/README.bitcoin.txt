Cracking bitcoin-qt (bitcoin) wallet files with john
====================================================

1. Run bitcoin2john.py on bitcoin wallet file(s).

E.g. $ ../run/bitcoin2john.py wallet.dat >> hashes

2. Run john on the output of bitcoin2john.py script.

E.g. $ ../run/john hashes

3. Wait for the password(s) to get cracked.
