README CUDA:

CUDA support has been dropped. The last git revision containing CUDA was
aa3602b. Note that an OpenCL build has much more (and better) formats than
a CUDA-only build anyway - and nvidia works perfectly fine with OpenCL.
