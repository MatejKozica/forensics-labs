import os
import pandas as pd
import hashlib
from magic import magic
import mimetypes

dir_path = "./Dokaz"
target_hash = 'c15e32d27635f248c1c8b66bb012850e5b342119'

file_names = []
extensions = []
md5s = []
sha1s = []
sha256s = []
magic_numbers = []
extension_matches = []

magic_reader = magic.Magic(uncompress=True,mime=True)

for file in os.listdir(dir_path):
    # check if the file is a regular file (i.e., not a directory)
    if os.path.isfile(os.path.join(dir_path, file)):
        # if so, add the file name to the list
        [file_name, extension] = os.path.splitext(file)

        with open(os.path.join(dir_path, file), 'rb') as f:
            md5s.append(hashlib.md5(f.read()).hexdigest())
            sha1s.append(hashlib.sha1(f.read()).hexdigest())
            sha256s.append(hashlib.sha256(f.read()).hexdigest())
        
        magic_number=magic_reader.from_file(os.path.join(dir_path,file))
        magic_numbers.append(magic_number)

        if extension.lower() == '':
            extension_matches.append(False)
        elif mimetypes.guess_type('test'+extension.lower())[0] in magic_number.lower():
            extension_matches.append(True)
        else:
            extension_matches.append(False)

        file_names.append(file_name)
        extensions.append(extension)


df = pd.DataFrame({'file_name': file_names, 'extension': extensions, 'md5': md5s, 'sha1': sha1s, 'sha256': sha256s, 'magic_number': magic_numbers, 'extenstion_matches': extension_matches})

print(df)

print((df['md5'].eq(target_hash)).any())
print((df['sha1'].eq(target_hash)).any())
print((df['sha256'].eq(target_hash)).any())
print((df[df['sha1'] == target_hash]))
